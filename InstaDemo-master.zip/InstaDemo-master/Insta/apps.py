from django.apps import AppConfig


class InstaConfig(AppConfig):
    name = 'Insta'
